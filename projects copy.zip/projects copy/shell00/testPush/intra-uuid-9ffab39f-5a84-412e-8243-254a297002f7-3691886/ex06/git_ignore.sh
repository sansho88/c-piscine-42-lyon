#!/bin/bash
git ls-files -o --exclude-standard
