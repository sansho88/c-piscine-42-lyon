#!/bin/bash
git log --pretty="%H"
