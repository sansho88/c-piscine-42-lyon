/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bigheader.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tgriffit <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/08 14:40:36 by tgriffit          #+#    #+#             */
/*   Updated: 2021/08/08 15:22:47 by tgriffit         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <unistd.h>

void	ft_ft(int * val);
void	ft_swap(int *a, int *b);
void	ft_ultimate_div_mod(int *a, int *b);
void 	ft_putstr(char *str);
