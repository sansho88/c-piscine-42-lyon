find . | wc -l | tr -d ' '
