/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_splitnumber.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tgriffit <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/21 11:58:28 by tgriffit          #+#    #+#             */
/*   Updated: 2021/08/21 11:58:32 by tgriffit         ###   ########lyon.fr   */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>
#include <ourlib.h>

void ft_fill0(char *nbr)
{
	
}

char	**ft_splitnumber(char *str)
{
	char **nbsplit;
	int nbrsize;

	nbrsize = ft_strlen(str);
	nbsplit = malloc(nbrsize * sizeof(int));
	while (str[i])
	{

	}
}
