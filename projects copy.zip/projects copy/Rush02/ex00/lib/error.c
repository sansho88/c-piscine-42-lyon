/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tgriffit <tgriffit@student.42lyon.fr>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/22 23:00:28 by tgriffit          #+#    #+#             */
/*   Updated: 2021/08/22 23:00:28 by tgriffit         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include "ourlib.h"
typedef struct s_numbers
{
	char	*key;
}	t_map;

void is_param_valid(char *param)
{

}