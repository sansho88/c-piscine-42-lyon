#include "ft_abs.h"

#include "printf.h"
int main(void)
{
	printf("%d",ABS(-3.65));
}